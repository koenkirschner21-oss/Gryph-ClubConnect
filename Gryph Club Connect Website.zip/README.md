
  # Gryph Club Connect Website

  This is a code bundle for Gryph Club Connect Website. The original project is available at https://www.figma.com/design/y4fH7xWmXQdIwVNdOutE9N/Gryph-Club-Connect-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  