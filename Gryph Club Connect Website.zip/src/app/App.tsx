import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { SocialProofTicker } from './components/SocialProofTicker';
import { ProblemStatement } from './components/ProblemStatement';
import { FeaturesGrid } from './components/FeaturesGrid';
import { AppShowcase } from './components/AppShowcase';
import { HowItWorks } from './components/HowItWorks';
import { Pricing } from './components/Pricing';
import { Testimonials } from './components/Testimonials';
import { FinalCTA } from './components/FinalCTA';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-[#0A0A0A] font-[Inter] antialiased">
      <Navigation />
      <Hero />
      <SocialProofTicker />
      <ProblemStatement />
      <FeaturesGrid />
      <AppShowcase />
      <HowItWorks />
      <Pricing />
      <Testimonials />
      <FinalCTA />
      <Footer />
    </div>
  );
}
