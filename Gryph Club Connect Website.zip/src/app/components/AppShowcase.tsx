import { motion } from 'motion/react';
import { Check } from 'lucide-react';

export function AppShowcase() {
  return (
    <div className="bg-[#0A0A0A]">
      {/* Block A - Channels */}
      <section className="py-24">
        <div className="max-w-[1300px] mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Copy Left */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-[11px] font-bold text-[#C8102E] tracking-[0.12em] uppercase mb-4">
                Communication
              </div>
              <h2 className="text-[40px] font-extrabold text-white leading-[1.1] mb-6">
                Stop losing messages. Start leading conversations.
              </h2>
              <p className="text-[16px] text-[#B0B0B0] leading-relaxed mb-6">
                Create dedicated channels for every team — all-members, exec, marketing, events. Real-time messages, mentions (@James), and notifications so nothing slips through.
              </p>
              <ul className="space-y-3">
                {[
                  'Club-wide announcements to all members',
                  'Team-specific private channels',
                  '@mentions and push notifications',
                  'Message history — searchable, permanent'
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="mt-0.5 w-5 h-5 rounded-full bg-[#C8102E]/20 flex items-center justify-center flex-shrink-0">
                      <Check className="w-3 h-3 text-[#C8102E]" />
                    </div>
                    <span className="text-[15px] text-[#B0B0B0]">{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>

            {/* Image Right */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative"
            >
              <ChannelsMockup />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Block B - Tasks */}
      <section className="py-24 bg-[#111111]">
        <div className="max-w-[1300px] mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Image Left */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative order-2 lg:order-1"
            >
              <TasksMockup />
            </motion.div>

            {/* Copy Right */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="order-1 lg:order-2"
            >
              <div className="text-[11px] font-bold text-[#F5B800] tracking-[0.12em] uppercase mb-4">
                Task Management
              </div>
              <h2 className="text-[40px] font-extrabold text-white leading-[1.1] mb-6">
                Every task. Every owner. Every deadline.
              </h2>
              <p className="text-[16px] text-[#B0B0B0] leading-relaxed mb-6">
                Create tasks, assign them to specific members, set due dates, and track progress. No more "I thought you were doing that."
              </p>
              <ul className="space-y-3">
                {[
                  'Task creation with assignee + due date',
                  'Status columns: To Do / In Progress / Complete',
                  'Club-wide task visibility for execs',
                  'Completion tracking and accountability'
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="mt-0.5 w-5 h-5 rounded-full bg-[#F5B800]/20 flex items-center justify-center flex-shrink-0">
                      <Check className="w-3 h-3 text-[#F5B800]" />
                    </div>
                    <span className="text-[15px] text-[#B0B0B0]">{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Block C - Events */}
      <section className="py-24">
        <div className="max-w-[1300px] mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Copy Left */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-[11px] font-bold text-[#C8102E] tracking-[0.12em] uppercase mb-4">
                Event Planning
              </div>
              <h2 className="text-[40px] font-extrabold text-white leading-[1.1] mb-6">
                Plan once. Everyone shows up.
              </h2>
              <p className="text-[16px] text-[#B0B0B0] leading-relaxed mb-6">
                Add events to your shared club calendar. Members RSVP directly in the platform. Automated reminders before every event.
              </p>
              <ul className="space-y-3">
                {[
                  'Shared calendar all members can view',
                  'One-click RSVP with attendance tracking',
                  'Automatic event reminders',
                  'RSVP count visible to organizers'
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="mt-0.5 w-5 h-5 rounded-full bg-[#C8102E]/20 flex items-center justify-center flex-shrink-0">
                      <Check className="w-3 h-3 text-[#C8102E]" />
                    </div>
                    <span className="text-[15px] text-[#B0B0B0]">{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>

            {/* Image Right */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative"
            >
              <EventsMockup />
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
}

function ChannelsMockup() {
  return (
    <div className="bg-[#161616] rounded-2xl shadow-[0_8px_32px_rgba(0,0,0,0.5)] border border-white/10 overflow-hidden">
      <div className="flex h-[400px]">
        {/* Sidebar */}
        <div className="w-[160px] bg-[#111111] p-4 flex flex-col">
          <div className="text-[10px] font-bold text-[#666666] tracking-[0.1em] uppercase mb-2">Channels</div>
          {[
            { name: '#general', unread: false },
            { name: '#events', unread: true },
            { name: '#marketing', unread: false }
          ].map((channel, i) => (
            <div
              key={i}
              className={`px-2 py-1.5 rounded text-[11px] font-medium mb-1 ${
                channel.unread
                  ? 'bg-[#C8102E]/15 text-white'
                  : 'text-[#B0B0B0]'
              }`}
            >
              <span className="font-mono">{channel.name}</span>
              {channel.unread && (
                <span className="ml-2 px-1.5 py-0.5 rounded-full bg-[#C8102E] text-white text-[9px] font-bold">
                  3
                </span>
              )}
            </div>
          ))}
        </div>

        {/* Chat */}
        <div className="flex-1 bg-[#161616] flex flex-col">
          <div className="h-12 px-4 flex items-center border-b border-white/10">
            <span className="font-mono text-white text-[13px] font-bold"># events</span>
          </div>
          <div className="flex-1 px-4 py-3 space-y-3 overflow-auto">
            {[
              { user: 'Priya', msg: 'Winter Gala planning starts...' },
              { user: 'James', msg: 'I can help with venue booking' }
            ].map((m, i) => (
              <div key={i} className="flex gap-2">
                <div className="w-6 h-6 rounded-full bg-purple-600 flex items-center justify-center text-white text-[9px] font-bold flex-shrink-0">
                  {m.user[0]}
                </div>
                <div>
                  <div className="text-[11px] font-semibold text-white">{m.user}</div>
                  <div className="text-[11px] text-[#B0B0B0]">{m.msg}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function TasksMockup() {
  return (
    <div className="bg-[#161616] rounded-2xl shadow-[0_8px_32px_rgba(0,0,0,0.5)] border border-white/10 p-6">
      <div className="flex gap-4">
        {[
          { title: 'TO DO', color: '#C8102E', tasks: 2 },
          { title: 'IN PROGRESS', color: '#F59E0B', tasks: 1 },
          { title: 'COMPLETE', color: '#22C55E', tasks: 3 }
        ].map((col, i) => (
          <div key={i} className="flex-1">
            <div
              className="text-[10px] font-bold tracking-[0.1em] uppercase mb-3 pb-2 border-b-2"
              style={{ color: col.color, borderColor: col.color }}
            >
              {col.title}
            </div>
            <div className="space-y-2">
              {Array.from({ length: col.tasks }).map((_, idx) => (
                <div key={idx} className="bg-[#0A0A0A] border border-white/10 rounded-lg p-3">
                  <div className="text-[11px] text-white font-medium mb-2">Task item</div>
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 rounded-full bg-blue-600 flex items-center justify-center text-white text-[8px] font-bold">
                      J
                    </div>
                    <span className="text-[9px] text-[#666666]">Dec 15</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 pt-4 border-t border-white/10">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] text-[#B0B0B0]">Overall Progress</span>
          <span className="text-[11px] font-bold text-white">50%</span>
        </div>
        <div className="h-2 bg-[#0A0A0A] rounded-full overflow-hidden">
          <div className="h-full w-1/2 bg-gradient-to-r from-[#C8102E] to-[#F5B800]" />
        </div>
      </div>
    </div>
  );
}

function EventsMockup() {
  return (
    <div className="bg-[#161616] rounded-2xl shadow-[0_8px_32px_rgba(0,0,0,0.5)] border border-white/10 p-6">
      <div className="grid grid-cols-7 gap-1 mb-4">
        {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, i) => (
          <div key={i} className="text-center text-[10px] text-[#666666] font-bold">
            {day}
          </div>
        ))}
        {Array.from({ length: 35 }).map((_, i) => {
          const hasEvent = [8, 14, 21].includes(i);
          return (
            <div
              key={i}
              className={`aspect-square flex items-center justify-center text-[11px] rounded ${
                hasEvent
                  ? 'bg-[#C8102E] text-white font-bold'
                  : i < 4
                  ? 'text-[#666666]'
                  : 'text-[#B0B0B0]'
              }`}
            >
              {i + 1}
            </div>
          );
        })}
      </div>
      <div className="bg-[#0A0A0A] border border-white/10 rounded-lg p-4">
        <div className="text-[13px] font-bold text-white mb-2">Winter Gala</div>
        <div className="text-[11px] text-[#B0B0B0] mb-3">Dec 14 · 📍 UC</div>
        <div className="flex items-center gap-2">
          <div className="px-3 py-1 rounded-full bg-[#22C55E]/20 border border-[#22C55E]/30">
            <span className="text-[10px] font-semibold text-[#22C55E]">✅ 24 RSVPs</span>
          </div>
        </div>
        <button className="mt-3 w-full py-2 rounded-lg bg-gradient-to-r from-[#C8102E] to-[#8B0000] text-white text-[12px] font-semibold">
          RSVP Now
        </button>
      </div>
    </div>
  );
}
