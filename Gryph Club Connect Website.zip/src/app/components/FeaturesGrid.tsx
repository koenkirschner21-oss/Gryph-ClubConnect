import { motion } from 'motion/react';
import { MessageSquare, CheckSquare, Calendar, Users, Layers, BarChart3, ArrowRight } from 'lucide-react';

export function FeaturesGrid() {
  const features = [
    {
      icon: MessageSquare,
      tag: 'COMMUNICATION',
      title: 'Team Channels',
      description: 'Separate channels for all-hands, exec team, marketing, events, and more. No more mixed-up group chats.',
      accent: 'red'
    },
    {
      icon: CheckSquare,
      tag: 'TASK MANAGEMENT',
      title: 'Task Tracker',
      description: 'Assign tasks, set deadlines, track To Do → In Progress → Complete. Accountability built in.',
      accent: 'gold'
    },
    {
      icon: Calendar,
      tag: 'EVENTS',
      title: 'Shared Event Calendar',
      description: 'Create events, collect RSVPs, send reminders. Your whole club sees what\'s happening and when.',
      accent: 'red'
    },
    {
      icon: Users,
      tag: 'MEMBERS',
      title: 'Member Directory',
      description: 'Every member\'s name, role, photo, and contact info — searchable, role-gated, always up to date.',
      accent: 'gold'
    },
    {
      icon: Layers,
      tag: 'MULTI-CLUB',
      title: 'Belong to Multiple Clubs',
      description: 'One account. Switch between Marketing Club, Engineering Society, and Finance Club from a single sidebar. No separate logins. No data mixing.',
      accent: 'red',
      wide: true
    },
    {
      icon: BarChart3,
      tag: 'ADMIN',
      title: 'Club Admin Dashboard',
      description: 'Monitor task completion rates, member engagement, RSVP counts, and channel activity. Run your club like a leader.',
      accent: 'gold'
    }
  ];

  return (
    <section className="bg-[#0A0A0A] py-24" id="features">
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-[860px] mx-auto mb-16"
        >
          <div className="text-[11px] font-bold text-[#C8102E] tracking-[0.12em] uppercase mb-4">
            Core Platform
          </div>
          <h2 className="text-[48px] md:text-[56px] font-extrabold text-white leading-[1.1] mb-4">
            Everything your club needs, finally in one place.
          </h2>
          <p className="text-[18px] text-[#B0B0B0]">
            Built specifically for student organizations. Not a social app. Not a generic project tool. A purpose-built club OS.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => {
            const accentColor = feature.accent === 'gold' ? '#F5B800' : '#C8102E';
            const accentColorRgb = feature.accent === 'gold' ? '245,184,0' : '200,16,46';

            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className={`bg-[#161616] border border-white/[0.06] rounded-2xl p-8 hover:shadow-[0_8px_32px_rgba(${accentColorRgb},0.15)] hover:border-[${accentColor}]/20 hover:-translate-y-1 transition-all duration-200 ${
                  feature.wide ? 'md:col-span-2' : ''
                }`}
              >
                {/* Icon Container */}
                <div
                  className={`w-12 h-12 rounded-lg mb-4 flex items-center justify-center`}
                  style={{
                    backgroundColor: `${accentColor}1F`,
                    borderWidth: '1px',
                    borderColor: `${accentColor}33`
                  }}
                >
                  <feature.icon className="w-6 h-6" style={{ color: accentColor }} />
                </div>

                {/* Tag */}
                <div
                  className="text-[10px] font-bold tracking-[0.1em] uppercase mb-3"
                  style={{ color: accentColor }}
                >
                  {feature.tag}
                </div>

                {/* Title */}
                <h3 className="text-[20px] font-bold text-white mb-3">{feature.title}</h3>

                {/* Description */}
                <p className="text-[14px] text-[#B0B0B0] leading-relaxed mb-4">
                  {feature.description}
                </p>

                {/* Footer Link */}
                <a
                  href="#"
                  className="inline-flex items-center gap-1 text-[14px] font-semibold group"
                  style={{ color: accentColor }}
                >
                  Learn more
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
                </a>

                {/* Wide card mockup */}
                {feature.wide && (
                  <div className="mt-6 flex gap-2">
                    {[
                      { initials: 'GMA', color: 'bg-red-600' },
                      { initials: 'ESS', color: 'bg-blue-600' },
                      { initials: 'GFAB', color: 'bg-yellow-600' }
                    ].map((club, idx) => (
                      <div key={idx} className="flex items-center gap-2 px-3 py-2 rounded-lg bg-[#0A0A0A] border border-white/10">
                        <div className={`w-6 h-6 rounded-full ${club.color} flex items-center justify-center text-white text-[9px] font-bold`}>
                          {club.initials}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
