import { motion } from 'motion/react';
import { Lock } from 'lucide-react';

export function FinalCTA() {
  return (
    <section className="bg-[#0A0A0A] py-32 relative overflow-hidden">
      {/* Background Griffin Watermark */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.06]">
        <svg width="400" height="400" viewBox="0 0 400 400" fill="none" className="text-[#C8102E]">
          <path
            d="M200 100 L250 150 L300 140 L280 180 L320 220 L270 230 L280 280 L240 260 L200 300 L160 260 L120 280 L130 230 L80 220 L120 180 L100 140 L150 150 Z"
            fill="currentColor"
          />
        </svg>
      </div>

      <div className="max-w-[800px] mx-auto px-6 text-center relative z-10">
        {/* Eyebrow Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#C8102E]/[0.10] border border-[#C8102E]/20 mb-8"
        >
          <div className="w-2 h-2 rounded-full bg-[#C8102E] animate-pulse" />
          <span className="text-[11px] font-bold text-[#C8102E] tracking-[0.1em] uppercase">
            Now Available at UofG
          </span>
        </motion.div>

        {/* H2 */}
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-[48px] md:text-[56px] font-black text-white leading-[1.1] mb-6"
        >
          Your club deserves better than a group chat.
        </motion.h2>

        {/* Subheading */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-[20px] text-[#B0B0B0] max-w-[560px] mx-auto mb-8"
        >
          Join every UofG club already running on Gryph Club Connect. Free to start, built to scale.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="flex flex-wrap items-center justify-center gap-4 mb-8"
        >
          <button className="px-10 py-[18px] rounded-[10px] bg-gradient-to-r from-[#C8102E] to-[#8B0000] text-white text-[15px] font-semibold shadow-[0_4px_24px_rgba(200,16,46,0.35)] hover:shadow-[0_6px_32px_rgba(200,16,46,0.45)] hover:brightness-110 transition-all duration-200 flex items-center gap-2">
            Create Your Club Free <span>→</span>
          </button>
          <button className="px-10 py-[18px] rounded-[10px] border border-white/20 bg-transparent text-white text-[15px] font-semibold hover:border-white/40 hover:bg-white/5 transition-all duration-200">
            Book a Demo
          </button>
        </motion.div>

        {/* Trust Line */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="flex items-center justify-center gap-3 text-[12px] text-[#666666]"
        >
          <div className="flex items-center gap-1.5">
            <Lock className="w-3 h-3" />
            <span>@uoguelph.ca emails only</span>
          </div>
          <span>·</span>
          <span>Free forever plan</span>
          <span>·</span>
          <span>No credit card needed</span>
        </motion.div>
      </div>
    </section>
  );
}
