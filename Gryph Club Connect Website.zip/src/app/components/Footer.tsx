import { Instagram, Linkedin, Twitter } from 'lucide-react';

export function Footer() {
  const footerLinks = {
    product: [
      { label: 'Features', href: '#features' },
      { label: 'How It Works', href: '#how-it-works' },
      { label: 'Pricing', href: '#pricing' },
      { label: 'For Club Executives', href: '#' },
      { label: 'Mobile App (Coming Soon)', href: '#' }
    ],
    company: [
      { label: 'About', href: '#' },
      { label: 'Blog', href: '#' },
      { label: 'Contact', href: '#' },
      { label: 'Careers', href: '#' },
      { label: 'Privacy Policy', href: '#' },
      { label: 'Terms of Service', href: '#' }
    ]
  };

  return (
    <footer className="bg-[#080808] border-t border-white/[0.06]">
      <div className="max-w-[1400px] mx-auto px-6 py-16">
        {/* Top Row */}
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          {/* Col 1 - Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <img
                src="figma:asset/7e2745b2b38de149f68002fea952d0fc30b0b34f.png"
                alt="Gryph Club Connect"
                className="h-[32px] w-auto"
              />
            </div>
            <p className="text-[13px] text-[#666666] leading-relaxed mb-6">
              The official club management platform for University of Guelph.
            </p>
            {/* Social Icons */}
            <div className="flex items-center gap-4">
              <a
                href="#"
                className="w-8 h-8 rounded-full bg-[#161616] border border-white/10 flex items-center justify-center text-[#666666] hover:text-white hover:border-white/20 transition-all duration-200"
              >
                <Instagram size={16} />
              </a>
              <a
                href="#"
                className="w-8 h-8 rounded-full bg-[#161616] border border-white/10 flex items-center justify-center text-[#666666] hover:text-white hover:border-white/20 transition-all duration-200"
              >
                <Linkedin size={16} />
              </a>
              <a
                href="#"
                className="w-8 h-8 rounded-full bg-[#161616] border border-white/10 flex items-center justify-center text-[#666666] hover:text-white hover:border-white/20 transition-all duration-200"
              >
                <Twitter size={16} />
              </a>
            </div>
          </div>

          {/* Col 2 - Product */}
          <div>
            <h4 className="text-[14px] font-bold text-white mb-4 uppercase tracking-[0.05em]">
              Product
            </h4>
            <ul className="space-y-3">
              {footerLinks.product.map((link, i) => (
                <li key={i}>
                  <a
                    href={link.href}
                    className="text-[14px] text-[#666666] hover:text-white transition-colors duration-200"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3 - Company */}
          <div>
            <h4 className="text-[14px] font-bold text-white mb-4 uppercase tracking-[0.05em]">
              Company
            </h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link, i) => (
                <li key={i}>
                  <a
                    href={link.href}
                    className="text-[14px] text-[#666666] hover:text-white transition-colors duration-200"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4 - Get Started */}
          <div>
            <h4 className="text-[14px] font-bold text-white mb-4 uppercase tracking-[0.05em]">
              Get Started
            </h4>
            <button className="w-full mb-4 px-6 py-3 rounded-[10px] bg-gradient-to-r from-[#C8102E] to-[#8B0000] text-white text-[14px] font-semibold shadow-[0_4px_16px_rgba(200,16,46,0.3)] hover:shadow-[0_6px_24px_rgba(200,16,46,0.4)] hover:brightness-110 transition-all duration-200">
              Join Free
            </button>
            <a
              href="#"
              className="block text-[14px] text-[#F5B800] hover:text-[#D4A017] transition-colors duration-200"
            >
              For university partnerships →
            </a>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/[0.06] flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-[13px] text-[#666666]">
            © 2026 Gryph Club Connect. University of Guelph. All rights reserved.
          </div>
          <div className="text-[13px] text-[#666666]">
            Made in Guelph, Ontario 🦁
          </div>
        </div>
      </div>
    </footer>
  );
}
