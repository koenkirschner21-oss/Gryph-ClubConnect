import { motion } from 'motion/react';
import { GraduationCap } from 'lucide-react';

export function Hero() {
  return (
    <section className="relative min-h-screen bg-[#0A0A0A] pt-[72px] overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Grid Dots Pattern */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: 'radial-gradient(circle, #FFFFFF 1px, transparent 1px)',
            backgroundSize: '24px 24px'
          }}
        />
        {/* Red Glow Top Right */}
        <div
          className="absolute top-0 right-0 w-[800px] h-[800px] opacity-[0.08]"
          style={{
            background: 'radial-gradient(circle, #C8102E 0%, transparent 70%)'
          }}
        />
        {/* Horizontal Beam */}
        <div
          className="absolute top-[20%] left-0 right-0 h-[2px] opacity-[0.02]"
          style={{
            background: 'linear-gradient(90deg, transparent, #C8102E, transparent)'
          }}
        />
      </div>

      <div className="max-w-[1400px] mx-auto px-6 py-20 relative z-10">
        <div className="grid lg:grid-cols-[60fr_40fr] gap-12 items-center">
          {/* Left Copy */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-8"
          >
            {/* Eyebrow Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#C8102E]/[0.12] border border-[#C8102E]/25">
              <GraduationCap size={14} className="text-[#C8102E]" />
              <span className="text-[11px] font-bold text-[#C8102E] tracking-[0.1em] uppercase">
                Official Campus Platform — University of Guelph
              </span>
            </div>

            {/* H1 */}
            <div className="space-y-2">
              <h1 className="text-[80px] md:text-[96px] font-black tracking-[-0.04em] leading-[0.95] text-white">
                Every Club.
              </h1>
              <h1 className="text-[80px] md:text-[96px] font-black tracking-[-0.04em] leading-[0.95] text-[#F5B800]">
                One Platform.
              </h1>
            </div>

            {/* Subheading */}
            <p className="text-[20px] font-light text-[#B0B0B0] max-w-[520px] leading-[1.6]">
              Replace scattered group chats, missed emails, and lost tasks. Gryph Club Connect gives every UofG student organization a professional home base — built around the way clubs actually work.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4">
              <button className="px-8 py-4 rounded-[10px] bg-gradient-to-r from-[#C8102E] to-[#8B0000] text-white text-[15px] font-semibold shadow-[0_4px_24px_rgba(200,16,46,0.35)] hover:shadow-[0_6px_32px_rgba(200,16,46,0.45)] hover:brightness-110 transition-all duration-200 flex items-center gap-2">
                Get Started Free <span>→</span>
              </button>
              <button className="px-8 py-4 rounded-[10px] border border-white/20 bg-transparent text-white text-[15px] font-semibold hover:border-white/40 hover:bg-white/5 transition-all duration-200">
                See a Demo
              </button>
            </div>

            {/* Stats Row */}
            <div className="pt-8 border-t border-white/[0.08]">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {[
                  { value: 'UofG Only', label: 'Private Campus Network' },
                  { value: '4', label: 'Core Modules' },
                  { value: '5 min', label: 'Setup Time' },
                  { value: 'Free', label: 'To Get Started' }
                ].map((stat, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.7 + i * 0.1 }}
                  >
                    <div className="text-[36px] font-extrabold text-white leading-none">
                      {stat.value}
                    </div>
                    <div className="text-[12px] font-bold text-[#666666] uppercase tracking-[0.05em] mt-1">
                      {stat.label}
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Right - App Mockup */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="relative hidden lg:block"
          >
            <motion.div
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
              className="bg-[#0A0A0A] rounded-[20px] shadow-[0_32px_80px_rgba(0,0,0,0.8)] border border-white/10 overflow-hidden"
            >
              <AppMockup />
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function AppMockup() {
  return (
    <div className="flex h-[600px] bg-[#0A0A0A]">
      {/* Sidebar */}
      <div className="w-[220px] bg-[#111111] p-5 flex flex-col">
        {/* Logo */}
        <div className="flex items-center gap-2 mb-6">
          <div className="w-6 h-6 rounded bg-[#C8102E] flex items-center justify-center text-white text-[10px] font-bold">
            G
          </div>
          <span className="text-[13px] font-bold text-white">Gryph Club Connect</span>
        </div>

        {/* MY CLUBS Section */}
        <div className="space-y-3">
          <div className="text-[10px] font-bold text-[#666666] tracking-[0.1em] uppercase">My Clubs</div>

          {[
            { initials: 'GMA', name: 'Marketing Club', badge: '3', color: 'bg-red-600' },
            { initials: 'ESS', name: 'Engineering Society', subtitle: 'Meeting at 5pm', color: 'bg-blue-600' },
            { initials: 'GFAB', name: 'Finance & Business', subtitle: 'New message', color: 'bg-yellow-600' }
          ].map((club, i) => (
            <div key={i} className="flex items-center gap-2 p-2 rounded hover:bg-white/5 cursor-pointer">
              <div className={`w-8 h-8 rounded-full ${club.color} flex items-center justify-center text-white text-[10px] font-bold`}>
                {club.initials}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[11px] font-medium text-white truncate">{club.name}</div>
                {club.subtitle && (
                  <div className="text-[9px] text-[#666666] truncate">{club.subtitle}</div>
                )}
              </div>
              {club.badge && (
                <div className="w-5 h-5 rounded-full bg-[#C8102E] flex items-center justify-center text-white text-[9px] font-bold">
                  {club.badge}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Divider */}
        <div className="h-px bg-white/10 my-4" />

        {/* CHANNELS Section */}
        <div className="space-y-2 flex-1">
          <div className="text-[10px] font-bold text-[#666666] tracking-[0.1em] uppercase">Channels</div>

          {[
            { name: '#general', active: false },
            { name: '#events', active: true },
            { name: '#marketing', active: false },
            { name: '#exec-team', active: false }
          ].map((channel, i) => (
            <div
              key={i}
              className={`px-2 py-1.5 rounded text-[12px] font-medium cursor-pointer transition-colors ${
                channel.active
                  ? 'bg-[#C8102E]/15 text-white'
                  : 'text-[#B0B0B0] hover:bg-white/5'
              }`}
            >
              <span className="font-mono">{channel.name}</span>
            </div>
          ))}
        </div>

        {/* User Profile */}
        <div className="flex items-center gap-2 pt-3 border-t border-white/10">
          <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-white text-[10px] font-bold relative">
            PS
            <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-[#22C55E] border-2 border-[#111111]" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-[11px] font-medium text-white">Priya Sharma</div>
          </div>
        </div>
      </div>

      {/* Main Chat Pane */}
      <div className="flex-1 bg-[#161616] flex flex-col">
        {/* Header */}
        <div className="h-14 px-5 flex items-center justify-between border-b border-white/10">
          <div className="flex items-center gap-2">
            <span className="font-mono text-white font-bold"># events</span>
          </div>
          <div className="px-3 py-1 rounded-full bg-[#22C55E]/20 border border-[#22C55E]/30">
            <span className="text-[11px] font-semibold text-[#22C55E]">24 online</span>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 px-5 py-4 space-y-4 overflow-auto">
          {[
            {
              user: 'Priya Sharma',
              time: 'Today 2:14 PM',
              message: 'Winter Gala planning starts next week — let\'s nail this one 🔥',
              avatar: 'PS',
              color: 'bg-purple-600'
            },
            {
              user: 'James Okafor',
              time: 'Today 2:17 PM',
              message: 'I can help with venue booking. Already contacted UMFSC.',
              avatar: 'JO',
              color: 'bg-blue-600',
              task: true
            },
            {
              user: 'Anya Lee',
              time: 'Today 2:22 PM',
              message: '3 tasks due this week — I\'ll share the Gala doc',
              avatar: 'AL',
              color: 'bg-green-600'
            }
          ].map((msg, i) => (
            <div key={i} className="flex gap-3">
              <div className={`w-8 h-8 rounded-full ${msg.color} flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0`}>
                {msg.avatar}
              </div>
              <div className="flex-1">
                <div className="flex items-baseline gap-2 mb-1">
                  <span className="text-[13px] font-semibold text-white">{msg.user}</span>
                  <span className="text-[11px] text-[#666666]">{msg.time}</span>
                </div>
                <div className="text-[13px] text-[#B0B0B0] leading-relaxed">{msg.message}</div>
                {msg.task && (
                  <div className="mt-2 inline-flex items-center gap-2 px-3 py-1.5 rounded bg-[#F5B800]/10 border border-[#F5B800]/20">
                    <span className="text-[11px] text-[#F5B800]">✓ Task: Venue booking — assigned to James</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Message Input */}
        <div className="p-4 border-t border-white/10">
          <div className="flex items-center gap-2 px-4 py-2.5 bg-[#0A0A0A] rounded-lg border border-white/10">
            <input
              type="text"
              placeholder="Message #events..."
              className="flex-1 bg-transparent text-[13px] text-white placeholder:text-[#666666] outline-none"
            />
            <button className="w-8 h-8 rounded bg-[#C8102E] flex items-center justify-center text-white hover:brightness-110 transition-all">
              <span className="text-[16px]">→</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
