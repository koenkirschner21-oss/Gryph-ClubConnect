import { motion } from 'motion/react';

export function HowItWorks() {
  const steps = [
    {
      number: 1,
      title: 'Create Your Account',
      description: 'Sign up with your official @uoguelph.ca email. Verified university email required — no outside accounts.',
      active: true
    },
    {
      number: 2,
      title: 'Enter Your Club Code',
      description: 'Your club executive gives you a secure 6-digit access code. Enter it to join your club\'s private workspace.',
      active: false
    },
    {
      number: 3,
      title: 'Set Up Your Profile',
      description: 'Add your name, photo, year, and program. Your club directory updates automatically.',
      active: false
    },
    {
      number: 4,
      title: 'Start Collaborating',
      description: 'Jump into channels, check your tasks, see upcoming events. You\'re live.',
      active: false
    }
  ];

  return (
    <section className="bg-[#111111] py-24 relative overflow-hidden" id="how-it-works">
      {/* Background Glow */}
      <div
        className="absolute top-0 left-0 w-[600px] h-[600px] opacity-[0.04]"
        style={{
          background: 'radial-gradient(circle, #C8102E 0%, transparent 70%)'
        }}
      />

      <div className="max-w-[1300px] mx-auto px-6 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-[860px] mx-auto mb-16"
        >
          <div className="text-[11px] font-bold text-[#C8102E] tracking-[0.12em] uppercase mb-4">
            How It Works
          </div>
          <h2 className="text-[48px] font-extrabold text-white leading-[1.1]">
            Up and running in under 5 minutes.
          </h2>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Steps Left */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            {steps.map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="flex gap-4"
              >
                {/* Number Circle */}
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                    step.active
                      ? 'bg-[#C8102E]'
                      : 'border-2 border-[#C8102E]/40'
                  }`}
                >
                  <span
                    className={`text-[20px] font-bold ${
                      step.active ? 'text-white' : 'text-[#C8102E]'
                    }`}
                  >
                    {step.number}
                  </span>
                </div>

                {/* Content */}
                <div className="flex-1 pt-1">
                  <h3 className="text-[18px] font-bold text-white mb-2">{step.title}</h3>
                  <p className="text-[15px] text-[#B0B0B0] leading-relaxed">{step.description}</p>
                </div>
              </motion.div>
            ))}

            {/* Admin Note */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="mt-6 p-4 rounded-xl bg-[#F59E0B]/10 border border-[#F59E0B]/30"
            >
              <p className="text-[13px] text-[#B0B0B0] leading-relaxed">
                <span className="font-bold text-[#F59E0B]">Club presidents:</span> create your club space, generate your access code, invite your exec team, and build your channels — all in the same 5-minute setup.
              </p>
            </motion.div>
          </motion.div>

          {/* Mockup Right */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <SetupWizardMockup />
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function SetupWizardMockup() {
  return (
    <div className="bg-[#161616] rounded-[20px] shadow-[0_16px_48px_rgba(0,0,0,0.6)] border border-white/10 overflow-hidden">
      {/* Window Chrome */}
      <div className="h-10 bg-[#0A0A0A] border-b border-white/10 flex items-center px-4 gap-2">
        <div className="flex gap-1.5">
          <div className="w-3 h-3 rounded-full bg-[#EF4444]" />
          <div className="w-3 h-3 rounded-full bg-[#F59E0B]" />
          <div className="w-3 h-3 rounded-full bg-[#22C55E]" />
        </div>
        <div className="flex-1 flex justify-center">
          <div className="px-3 py-1 rounded bg-[#C8102E]/10 border border-[#C8102E]/20">
            <span className="text-[10px] font-bold text-[#C8102E] tracking-[0.1em] uppercase">
              Setup Wizard
            </span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-8 space-y-6">
        <div>
          <h3 className="text-[20px] font-bold text-white mb-2">Welcome to Gryph Club Connect</h3>
          <p className="text-[14px] text-[#B0B0B0]">Let's get your account set up in just a few steps.</p>
        </div>

        {/* Email Field */}
        <div>
          <label className="block text-[12px] font-semibold text-white mb-2">
            Official Guelph Email
          </label>
          <div className="flex items-center gap-2 px-4 py-3 bg-[#0A0A0A] rounded-lg border border-white/10">
            <input
              type="text"
              value="president@uoguelph.ca"
              readOnly
              className="flex-1 bg-transparent text-[14px] text-white outline-none"
            />
            <div className="w-5 h-5 rounded-full bg-[#22C55E] flex items-center justify-center">
              <span className="text-white text-[12px]">✓</span>
            </div>
          </div>
        </div>

        {/* Club Code Field */}
        <div>
          <label className="block text-[12px] font-semibold text-white mb-2">
            Club Access Code
          </label>
          <div className="flex gap-2">
            {['8', '7', '4', '2', '9', '1'].map((digit, i) => (
              <div
                key={i}
                className="flex-1 aspect-square max-w-[48px] flex items-center justify-center bg-[#0A0A0A] rounded-lg border border-[#C8102E]/30 text-[20px] font-bold text-white"
              >
                {digit}
              </div>
            ))}
          </div>
        </div>

        {/* Success Toast */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.8 }}
          className="px-4 py-3 rounded-lg bg-[#22C55E]/20 border border-[#22C55E]/30"
        >
          <p className="text-[13px] font-semibold text-[#22C55E]">
            Welcome to Gryph Club Connect! 👋
          </p>
        </motion.div>

        {/* CTA Button */}
        <button className="w-full py-3 rounded-lg bg-gradient-to-r from-[#C8102E] to-[#8B0000] text-white text-[15px] font-semibold shadow-[0_4px_16px_rgba(200,16,46,0.3)] hover:brightness-110 transition-all duration-200 flex items-center justify-center gap-2">
          Ready to collaborate! 🚀
        </button>
      </div>
    </div>
  );
}
