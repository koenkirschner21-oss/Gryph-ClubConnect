import { Menu, X } from 'lucide-react';
import { useState } from 'react';

export function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 h-[72px] bg-[#0A0A0A]/90 backdrop-blur-[20px] border-b border-white/[0.06]">
      <div className="max-w-[1400px] mx-auto px-6 h-full flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <img
            src="figma:asset/7e2745b2b38de149f68002fea952d0fc30b0b34f.png"
            alt="Gryph Club Connect"
            className="h-[40px] w-auto"
          />
        </div>

        {/* Center Nav Links - Desktop */}
        <div className="hidden md:flex items-center gap-8">
          {['Features', 'How It Works', 'Pricing', 'For Clubs', 'About'].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase().replace(/\s+/g, '-')}`}
              className="text-[14px] font-medium text-[#B0B0B0] hover:text-white transition-all duration-200 relative group"
            >
              {item}
              <span className="absolute bottom-[-4px] left-0 w-0 h-[2px] bg-[#C8102E] group-hover:w-full transition-all duration-200" />
            </a>
          ))}
        </div>

        {/* Right Buttons - Desktop */}
        <div className="hidden md:flex items-center gap-3">
          <button className="px-5 py-2 rounded-lg border border-white/15 text-[#B0B0B0] hover:text-white hover:border-white/30 transition-all duration-200 text-[14px] font-medium">
            Sign In
          </button>
          <button className="px-6 py-2 rounded-[10px] bg-gradient-to-r from-[#C8102E] to-[#8B0000] text-white text-[14px] font-semibold shadow-[0_4px_16px_rgba(200,16,46,0.3)] hover:shadow-[0_6px_24px_rgba(200,16,46,0.4)] hover:brightness-110 transition-all duration-200 flex items-center gap-2">
            Join Free <span>→</span>
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="md:hidden text-[#C8102E] p-2"
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-[72px] left-0 right-0 bg-[#0A0A0A] border-b border-white/[0.06] backdrop-blur-[20px]">
          <div className="flex flex-col p-6 gap-4">
            {['Features', 'How It Works', 'Pricing', 'For Clubs', 'About'].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase().replace(/\s+/g, '-')}`}
                className="text-[14px] font-medium text-[#B0B0B0] hover:text-white transition-all duration-200 py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                {item}
              </a>
            ))}
            <div className="flex flex-col gap-3 mt-4 pt-4 border-t border-white/10">
              <button className="w-full px-5 py-2 rounded-lg border border-white/15 text-[#B0B0B0] hover:text-white transition-all duration-200 text-[14px] font-medium">
                Sign In
              </button>
              <button className="w-full px-6 py-2 rounded-[10px] bg-gradient-to-r from-[#C8102E] to-[#8B0000] text-white text-[14px] font-semibold shadow-[0_4px_16px_rgba(200,16,46,0.3)] flex items-center justify-center gap-2">
                Join Free <span>→</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
