import { motion } from 'motion/react';
import { Check, X } from 'lucide-react';

export function Pricing() {
  const plans = [
    {
      name: 'Free',
      label: 'FREE',
      price: '$0',
      period: '/month',
      description: '',
      features: [
        { text: '1 club workspace', included: true },
        { text: 'Up to 20 members', included: true },
        { text: '3 channels', included: true },
        { text: 'Basic task tracking', included: true },
        { text: 'Event calendar', included: true },
        { text: 'Admin analytics', included: false },
        { text: 'Unlimited members', included: false },
        { text: 'Priority support', included: false }
      ],
      cta: 'Get Started',
      featured: false,
      accent: 'gray'
    },
    {
      name: 'Club Pro',
      label: 'CLUB PRO',
      price: '$9',
      period: '/month',
      description: 'Per club. Cancel anytime.',
      badge: 'MOST POPULAR',
      features: [
        { text: 'Unlimited members', included: true },
        { text: 'Unlimited channels', included: true },
        { text: 'Full task management with deadlines', included: true },
        { text: 'Event calendar + RSVP analytics', included: true },
        { text: 'Member directory with role permissions', included: true },
        { text: 'Admin engagement dashboard', included: true },
        { text: 'File sharing (coming soon)', included: true },
        { text: 'Priority support', included: true }
      ],
      cta: 'Start 14-Day Free Trial',
      featured: true,
      accent: 'red'
    },
    {
      name: 'Institutional',
      label: 'INSTITUTIONAL',
      price: 'Custom',
      period: '',
      description: 'University-wide licensing',
      features: [
        { text: 'All clubs on one university license', included: true },
        { text: 'Central admin oversight', included: true },
        { text: 'Cross-club analytics', included: true },
        { text: 'LMS and university SSO integration', included: true },
        { text: 'Dedicated support + onboarding', included: true }
      ],
      cta: 'Contact Us →',
      featured: false,
      accent: 'gold'
    }
  ];

  return (
    <section className="bg-[#0A0A0A] py-24" id="pricing">
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-[860px] mx-auto mb-16"
        >
          <div className="text-[11px] font-bold text-[#C8102E] tracking-[0.12em] uppercase mb-4">
            Pricing
          </div>
          <h2 className="text-[48px] font-extrabold text-white leading-[1.1] mb-4">
            Start free. Scale when you're ready.
          </h2>
          <p className="text-[18px] text-[#B0B0B0]">
            No credit card required. Built for students, priced for clubs.
          </p>
        </motion.div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          {plans.map((plan, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className={`relative bg-[#161616] rounded-2xl p-8 ${
                plan.featured
                  ? 'border-2 border-[#C8102E]/50 shadow-[0_0_40px_rgba(200,16,46,0.2)]'
                  : plan.accent === 'gold'
                  ? 'border border-[#F5B800]/30'
                  : 'border border-white/[0.06]'
              }`}
            >
              {/* Badge */}
              {plan.badge && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-[#C8102E] to-[#8B0000] text-white text-[10px] font-bold tracking-[0.1em] uppercase">
                  {plan.badge}
                </div>
              )}

              {/* Label */}
              <div
                className={`text-[11px] font-bold tracking-[0.1em] uppercase mb-4 ${
                  plan.accent === 'gold' ? 'text-[#F5B800]' : plan.featured ? 'text-[#C8102E]' : 'text-[#666666]'
                }`}
              >
                {plan.label}
              </div>

              {/* Price */}
              <div className="mb-2">
                <span className="text-[56px] font-extrabold text-white leading-none">
                  {plan.price}
                </span>
                {plan.period && (
                  <span className="text-[16px] text-[#666666]">{plan.period}</span>
                )}
              </div>

              {/* Description */}
              {plan.description && (
                <p className="text-[13px] text-[#B0B0B0] mb-6">{plan.description}</p>
              )}

              {/* Features */}
              <ul className="space-y-3 mb-8 mt-6">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <div
                      className={`mt-0.5 w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
                        feature.included
                          ? 'bg-[#22C55E]/20'
                          : 'bg-[#2A2A2A]'
                      }`}
                    >
                      {feature.included ? (
                        <Check className="w-3 h-3 text-[#22C55E]" />
                      ) : (
                        <X className="w-3 h-3 text-[#666666]" />
                      )}
                    </div>
                    <span
                      className={`text-[14px] ${
                        feature.included ? 'text-[#B0B0B0]' : 'text-[#666666]'
                      }`}
                    >
                      {feature.text}
                    </span>
                  </li>
                ))}
              </ul>

              {/* CTA Button */}
              <button
                className={`w-full py-3 rounded-[10px] text-[14px] font-semibold transition-all duration-200 ${
                  plan.featured
                    ? 'bg-gradient-to-r from-[#C8102E] to-[#8B0000] text-white shadow-[0_4px_16px_rgba(200,16,46,0.3)] hover:shadow-[0_6px_24px_rgba(200,16,46,0.4)] hover:brightness-110'
                    : plan.accent === 'gold'
                    ? 'bg-[#1A1A1A] border border-[#F5B800]/30 text-[#F5B800] hover:bg-[#F5B800]/10'
                    : 'border border-white/15 text-white hover:border-white/30 hover:bg-white/5'
                }`}
              >
                {plan.cta}
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
