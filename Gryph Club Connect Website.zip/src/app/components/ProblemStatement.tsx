import { motion } from 'motion/react';
import { MessageCircleX, ClipboardX, CalendarX } from 'lucide-react';

export function ProblemStatement() {
  const problems = [
    {
      icon: MessageCircleX,
      title: 'Fragmented Communication',
      description: 'Your announcements go to 4 different places. Half your members miss them.'
    },
    {
      icon: ClipboardX,
      title: 'No Task Accountability',
      description: 'Who was supposed to book the venue again? Nobody remembers. Nothing gets tracked.'
    },
    {
      icon: CalendarX,
      title: 'Event Planning Nightmares',
      description: 'Spreadsheets. Texts. Hoping people show up. There has to be a better way.'
    }
  ];

  return (
    <section className="bg-[#111111] py-24" id="problem">
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-[860px] mx-auto mb-16"
        >
          <div className="text-[11px] font-bold text-[#C8102E] tracking-[0.12em] uppercase mb-4">
            The Problem
          </div>
          <h2 className="text-[48px] font-extrabold text-white leading-[1.1] mb-4">
            Your club runs on chaos.
          </h2>
          <p className="text-[18px] text-[#B0B0B0]">
            Group chats buried in Instagram DMs. Tasks lost in email threads. New members who don't know what's going on. Sound familiar?
          </p>
        </motion.div>

        {/* Problem Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {problems.map((problem, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="bg-[#161616] border border-white/[0.06] rounded-2xl p-8 hover:shadow-[0_8px_32px_rgba(200,16,46,0.15)] hover:border-[#C8102E]/20 hover:-translate-y-0.5 transition-all duration-200"
            >
              <div className="w-12 h-12 rounded-lg bg-[#C8102E]/10 border border-[#C8102E]/20 flex items-center justify-center mb-4">
                <problem.icon className="w-6 h-6 text-[#C8102E]" />
              </div>
              <h3 className="text-[18px] font-bold text-white mb-3">{problem.title}</h3>
              <p className="text-[14px] text-[#B0B0B0] leading-relaxed">{problem.description}</p>
            </motion.div>
          ))}
        </div>

        {/* Solution Bridge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center"
        >
          <p className="text-[16px] text-[#B0B0B0] mb-4">
            Gryph Club Connect replaces all of it — with one workspace your whole club will actually use.
          </p>
          <div className="flex justify-center">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" className="text-[#C8102E]">
              <path
                d="M12 5v14m0 0l7-7m-7 7l-7-7"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
