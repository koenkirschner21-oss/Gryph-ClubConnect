export function SocialProofTicker() {
  const items = [
    '● SECURE @UOGUELPH.CA LOGIN',
    '● MULTI-CLUB DASHBOARD',
    '● REAL-TIME TEAM CHANNELS',
    '● TASK TRACKING & DEADLINES',
    '● SHARED EVENT CALENDAR',
    '● RSVP MANAGEMENT',
    '● MEMBER DIRECTORY',
    '● ROLE-BASED PERMISSIONS',
    '● ACCESS CODE CLUB JOINING',
    '● BUILT FOR GUELPH CLUBS ONLY'
  ];

  // Duplicate items for seamless loop
  const displayItems = [...items, ...items, ...items];

  return (
    <div className="w-full h-12 bg-[#111111] border-t border-b border-white/[0.06] overflow-hidden flex items-center relative">
      <style dangerouslySetInnerHTML={{
        __html: `
          @keyframes ticker-scroll {
            0% { transform: translateX(0); }
            100% { transform: translateX(-33.333%); }
          }
          .ticker-animate {
            animation: ticker-scroll 40s linear infinite;
          }
        `
      }} />
      <div className="flex ticker-animate whitespace-nowrap">
        {displayItems.map((item, i) => (
          <div key={i} className="inline-flex items-center px-6">
            <span className="text-[12px] font-semibold text-[#666666] tracking-[0.05em] uppercase">
              {item}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
