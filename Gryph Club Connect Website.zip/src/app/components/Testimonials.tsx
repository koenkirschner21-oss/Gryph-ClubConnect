import { motion } from 'motion/react';
import { Star } from 'lucide-react';

export function Testimonials() {
  const testimonials = [
    {
      quote: 'We used to run our whole club through Instagram DMs and a group chat. Gryph Club Connect completely changed how we operate — every exec actually knows what\'s happening now.',
      name: 'Priya Sharma',
      role: 'VP Marketing',
      org: 'Guelph Marketing Association',
      initials: 'PS',
      color: 'bg-[#C8102E]'
    },
    {
      quote: 'As president, the admin dashboard is everything. I can see who\'s done their tasks, how many people RSVP\'d, and what channels are actually being used.',
      name: 'James Okafor',
      role: 'President',
      org: 'Engineering Student Society',
      initials: 'JO',
      color: 'bg-[#1A1A3E]'
    },
    {
      quote: 'Joining three clubs without any confusion is actually possible now. One login, one dashboard — I switch between them in one click.',
      name: 'Anya Lee',
      role: 'Member',
      org: 'GFAB + ESS + GMA',
      initials: 'AL',
      color: 'bg-[#1A3A1A]'
    }
  ];

  return (
    <section className="bg-[#111111] py-24">
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-[860px] mx-auto mb-16"
        >
          <div className="text-[11px] font-bold text-[#C8102E] tracking-[0.12em] uppercase mb-4">
            From Guelph Students
          </div>
          <h2 className="text-[48px] font-extrabold text-white leading-[1.1]">
            Real clubs. Real results.
          </h2>
        </motion.div>

        {/* Testimonial Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="bg-[#161616] border-l-[3px] border-l-[#C8102E] border-r border-t border-b border-white/[0.06] rounded-2xl p-8 hover:shadow-[0_8px_32px_rgba(200,16,46,0.15)] hover:-translate-y-1 transition-all duration-200"
            >
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star key={star} className="w-4 h-4 fill-[#F5B800] text-[#F5B800]" />
                ))}
              </div>

              {/* Quote */}
              <p className="text-[15px] text-[#B0B0B0] leading-relaxed mb-6 italic">
                "{testimonial.quote}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full ${testimonial.color} flex items-center justify-center text-white text-[12px] font-bold`}>
                  {testimonial.initials}
                </div>
                <div>
                  <div className="text-[14px] font-bold text-white">{testimonial.name}</div>
                  <div className="text-[12px] text-[#666666]">
                    {testimonial.role} · {testimonial.org}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
