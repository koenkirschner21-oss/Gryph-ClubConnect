# Gryph Club Connect — Figma AI Landing Page Mega Prompt
## Top-100 Company Quality Landing Page Brief

---

## BRAND IDENTITY

**Product Name:** Gryph Club Connect
**Tagline:** Every Club. One Platform.
**Secondary tagline:** The professional home base for every University of Guelph student organization.
**Brand voice:** Confident, campus-native, clean. Feels like Slack met Linear and was built specifically for Guelph students. Serious product energy, not a school project.

**Logo:** Red griffin (facing right, wings up, gold wing accents) + wordmark: "Club" in bold red + "Connect" in bold gold. Use on dark backgrounds with white/light variants where needed. Griffin icon can be used standalone as favicon/avatar mark.

---

## COLOUR SYSTEM

| Role | Hex |
|------|-----|
| Page background (primary) | `#0A0A0A` |
| Page background (alt sections) | `#111111` |
| Card surfaces | `#161616` |
| Card borders | `#2A2A2A` |
| Primary Red (brand) | `#C8102E` |
| Deep Red (hover/gradient end) | `#8B0000` |
| Gold (brand accent) | `#F5B800` |
| Gold muted | `#D4A017` |
| White headings | `#FFFFFF` |
| Body text | `#B0B0B0` |
| Muted / captions | `#666666` |
| Success green | `#22C55E` |
| Warning amber | `#F59E0B` |
| Destructive red (status) | `#EF4444` |
| Online indicator | `#22C55E` |

**Gradient — Primary CTA:** `#C8102E` → `#8B0000` (left to right)
**Gradient — Gold accent:** `#F5B800` → `#D4A017`
**Gradient — Hero bg glow:** radial from `#C8102E` at 8% opacity centred top-right, bleeding into `#0A0A0A`
**Gradient — Section separator:** horizontal line `#C8102E` at 15% opacity

---

## TYPOGRAPHY

**Primary Font:** Inter (Google Fonts) — weights 300, 400, 500, 600, 700, 800, 900
**Monospace accent font:** JetBrains Mono — for code-like UI labels, channel names, status indicators

| Element | Size | Weight | Color |
|---------|------|--------|-------|
| Hero H1 | 80–96px | 900 Black | `#FFFFFF` |
| Hero H1 accent word | same | 900 | `#F5B800` (gold) |
| Section H2 | 48–56px | 800 | `#FFFFFF` |
| Card H3 | 20–24px | 700 | `#FFFFFF` |
| Body large | 18px | 400 | `#B0B0B0` |
| Body default | 15–16px | 400 | `#B0B0B0` |
| Labels / tags | 11px | 700 | ALL CAPS, letter-spacing 0.1em |
| Button text | 15px | 600 | `#FFFFFF` |
| Mono UI labels | 12px | 500 | JetBrains Mono, `#666666` |
| Fine print | 12px | 400 | `#666666` |

---

## COMPONENT TOKENS

**Border radius:**
- Cards: 16px
- Buttons (primary): 10px
- Buttons (pill): 9999px
- Input fields: 8px
- Avatar circles: 50%
- Status badges: 9999px
- Modal containers: 20px
- App mockup frame: 20px

**Shadows:**
- Card default: `0 1px 3px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.04)`
- Card hover: `0 8px 32px rgba(200,16,46,0.15), 0 0 0 1px rgba(200,16,46,0.2)`
- Gold hover: `0 8px 32px rgba(245,184,0,0.12)`
- CTA button: `0 4px 24px rgba(200,16,46,0.35)`
- App mockup: `0 32px 80px rgba(0,0,0,0.8)`

**Hover transitions:** all 0.2s ease. Cards lift 2px + shadow intensifies. Buttons brighten 10% + shadow grows. Arrow icons shift 4px right.

**Animations:**
- Scroll entry: fade-in + translateY(24px → 0), staggered 0.1s per element
- Hero: subtle grid dot pattern background at 3% opacity over `#0A0A0A`
- App mockup: slow float animation (up 8px / down 8px, 6s loop)
- Stats counter: number counts up on scroll entry
- Ticker: infinite left-scroll marquee
- Nothing bouncy. Nothing cartoonish. Everything purposeful.

---

## PAGE LAYOUT — SINGLE LANDING PAGE (SCROLL)

**Total sections:** 10
1. Navigation
2. Hero
3. Social Proof Ticker
4. Problem Statement
5. Features Grid
6. App UI Deep-Dive (alternating feature showcases)
7. How It Works
8. Pricing
9. Testimonials
10. Final CTA + Footer

---

## SECTION 1 — NAVIGATION

**Layout:** Full-width sticky navbar, `#0A0A0A` at 90% opacity + backdrop blur 20px. 1px bottom border `rgba(255,255,255,0.06)`. Height: 72px.

**Left:** Gryph Club Connect logo — griffin icon (red + gold) + "Club" bold red + "Connect" bold gold. 40px tall.

**Centre nav links** (Inter 14px, weight 500, `#B0B0B0`, hover `#FFFFFF`, underline on hover in `#C8102E`):
Features · How It Works · Pricing · For Clubs · About

**Right:**
- "Sign In" — ghost button, border `rgba(255,255,255,0.15)`, text `#B0B0B0`, 8px radius
- "Join Free →" — gradient `#C8102E` → `#8B0000`, white text, 10px radius, shadow `0 4px 16px rgba(200,16,46,0.3)`

**Mobile:** hamburger icon in `#C8102E`, full-screen dropdown with same links.

---

## SECTION 2 — HERO

**Background:** `#0A0A0A` with:
- Subtle grid dot matrix at 3% opacity covering full canvas
- Radial red glow (`#C8102E` at 8%) centred top-right quadrant
- Very faint red horizontal beam at 20% height, 2% opacity

**Layout:** Two-column, 60/40 split. Left = copy. Right = floating app mockup.

### LEFT COPY (vertically centred):

**Eyebrow badge:**
Pill shape, bg `#C8102E` at 12%, border `#C8102E` at 25%, text `#C8102E` 11px ALL CAPS weight 700:
"🎓 OFFICIAL CAMPUS PLATFORM — UNIVERSITY OF GUELPH"

**H1** (80–96px, weight 900, tight tracking -0.04em):
Line 1: "Every Club." — `#FFFFFF`
Line 2: "One Platform." — `#F5B800` (gold)

**Subheading** (20px, weight 300, `#B0B0B0`, max-width 520px, line-height 1.6):
"Replace scattered group chats, missed emails, and lost tasks. Gryph Club Connect gives every UofG student organization a professional home base — built around the way clubs actually work."

**Two CTA buttons (side by side, gap 16px):**
- "Get Started Free →" — gradient `#C8102E`→`#8B0000`, 14px weight 600, 10px radius, padding 16px 32px, shadow `0 4px 24px rgba(200,16,46,0.35)`
- "See a Demo" — border `rgba(255,255,255,0.2)`, bg transparent, text `#FFFFFF`, same size

**Stats row** (below 1px divider `rgba(255,255,255,0.08)`, padding-top 32px):
Four stats in a horizontal row — large number `#FFFFFF` 36px weight 800 + label 12px ALL CAPS `#666666`:
- **UofG Only** — "Private Campus Network"
- **4** — "Core Modules"
- **5 min** — "Setup Time"
- **Free** — "To Get Started"

### RIGHT — APP MOCKUP (floating, 20px radius, shadow):

Render a dark-mode desktop app UI showing:

**Left sidebar** (`#111111`, width 220px, 20px padding):
- Top: Griffin logo icon + "Gryph Club Connect" 13px bold white
- Section label "MY CLUBS" 10px ALL CAPS `#666666`
- Club list items (each: 36px avatar circle with club initials + club name + unread dot):
  - 🔴 GMA — Marketing Club — red dot "3"
  - 🔵 ESS — Engineering Society — "Meeting at 5pm"
  - 🟡 GFAB — Finance & Business — "New message"
- Divider
- Section label "CHANNELS" 10px ALL CAPS `#666666`
- `#general` — `#events` (highlighted, red bg at 15%) — `#marketing` — `#exec-team`
- Bottom: avatar circle "PS" + "Priya Sharma" + green online dot

**Main chat pane** (`#161616`, flex-fill):
- Header bar: `# events` bold white + "24 online" green pill right
- Message thread (3 messages, real names):
  - **Priya Sharma** Today 2:14 PM — "Winter Gala planning starts next week — let's nail this one 🔥"
  - **James Okafor** Today 2:17 PM — "I can help with venue booking. Already contacted UMFSC." + gold task pill: "✓ Task: Venue booking — assigned to James"
  - **Anya Lee** Today 2:22 PM — "3 tasks due this week — I'll share the Gala doc"
- Message input bar at bottom: "Message #events..." + send button in red

---

## SECTION 3 — SOCIAL PROOF TICKER

**Full-width strip, height 48px**
Background: `#111111`, 1px top + bottom borders `rgba(255,255,255,0.06)`
Infinite left-scroll marquee, no interaction.

Items (12px ALL CAPS Inter 600, `#666666`, red `#C8102E` dot separators):
"● SECURE @UOGUELPH.CA LOGIN · ● MULTI-CLUB DASHBOARD · ● REAL-TIME TEAM CHANNELS · ● TASK TRACKING & DEADLINES · ● SHARED EVENT CALENDAR · ● RSVP MANAGEMENT · ● MEMBER DIRECTORY · ● ROLE-BASED PERMISSIONS · ● ACCESS CODE CLUB JOINING · ● BUILT FOR GUELPH CLUBS ONLY ●"

---

## SECTION 4 — PROBLEM STATEMENT

**Background:** `#111111`
**Layout:** Centred, max-width 860px

**Eyebrow:** "THE PROBLEM" — 11px ALL CAPS `#C8102E`, letter-spacing 0.12em
**H2** (48px, weight 800, `#FFFFFF`, line-height 1.1):
"Your club runs on chaos."
**Sub** (18px `#B0B0B0`):
"Group chats buried in Instagram DMs. Tasks lost in email threads. New members who don't know what's going on. Sound familiar?"

**Three problem cards** (horizontal row, equal width):
Each: bg `#161616`, border `rgba(255,255,255,0.06)`, 16px radius, padding 32px

Card 1 — Icon: fractured speech bubble in red
Title: "Fragmented Communication" — 18px bold white
Body: "Your announcements go to 4 different places. Half your members miss them." — 14px `#B0B0B0`

Card 2 — Icon: clipboard with X in red
Title: "No Task Accountability" — 18px bold white
Body: "Who was supposed to book the venue again? Nobody remembers. Nothing gets tracked." — 14px `#B0B0B0`

Card 3 — Icon: calendar with question mark in red
Title: "Event Planning Nightmares" — 18px bold white
Body: "Spreadsheets. Texts. Hoping people show up. There has to be a better way." — 14px `#B0B0B0`

**Below cards — Solution bridge:**
Centred text: "Gryph Club Connect replaces all of it — with one workspace your whole club will actually use." — 16px `#B0B0B0`
Arrow pointing down in `#C8102E`

---

## SECTION 5 — FEATURES GRID

**Background:** `#0A0A0A`
**Eyebrow:** "CORE PLATFORM" — 11px ALL CAPS `#C8102E`
**H2:** "Everything your club needs, finally in one place." — 48px weight 800 `#FFFFFF`
**Sub:** "Built specifically for student organizations. Not a social app. Not a generic project tool. A purpose-built club OS." — 18px `#B0B0B0`

**6-card grid (3×2), each card 16px radius, bg `#161616`, border `rgba(255,255,255,0.06)`, padding 32px:**

**Card 1 — Team Channels** (red accent)
Icon container: 48px, bg `#C8102E` at 12%, border `#C8102E` at 20%, 10px radius — icon: speech bubbles
Tag: "COMMUNICATION" — 10px ALL CAPS `#C8102E`
H3: "Team Channels" — 20px bold white
Body: "Separate channels for all-hands, exec team, marketing, events, and more. No more mixed-up group chats." — 14px `#B0B0B0`
Footer link: "Learn more →" `#C8102E`

**Card 2 — Task Manager** (gold accent)
Icon: checkmark/list — container bg `#F5B800` at 12%, border `#F5B800` at 20%
Tag: "TASK MANAGEMENT" `#F5B800`
H3: "Task Tracker"
Body: "Assign tasks, set deadlines, track To Do → In Progress → Complete. Accountability built in."
Footer: `#F5B800`

**Card 3 — Event Calendar** (red accent)
Icon: calendar
Tag: "EVENTS"
H3: "Shared Event Calendar"
Body: "Create events, collect RSVPs, send reminders. Your whole club sees what's happening and when."

**Card 4 — Member Directory** (gold accent)
Icon: people/grid
Tag: "MEMBERS"
H3: "Member Directory"
Body: "Every member's name, role, photo, and contact info — searchable, role-gated, always up to date."

**Card 5 — Multi-Club Support** (red accent, WIDE card spanning 2 cols)
Icon: layers/switcher
Tag: "MULTI-CLUB"
H3: "Belong to Multiple Clubs"
Body: "One account. Switch between Marketing Club, Engineering Society, and Finance Club from a single sidebar. No separate logins. No data mixing."
Right side: mini sidebar mockup showing 3 club avatars stacked

**Card 6 — Admin Dashboard** (gold accent)
Icon: chart/monitor
Tag: "ADMIN"
H3: "Club Admin Dashboard"
Body: "Monitor task completion rates, member engagement, RSVP counts, and channel activity. Run your club like a leader."

---

## SECTION 6 — APP UI DEEP-DIVES (Alternating Feature Showcases)

Three alternating left/right feature blocks. Each: full-width, alternating `#0A0A0A` / `#111111`, padding 120px vertical.

### Block A — Channels (image right, copy left)

**Copy:**
Eyebrow: "COMMUNICATION" — 11px ALL CAPS `#C8102E`
H2: "Stop losing messages. Start leading conversations." — 40px bold white
Body: "Create dedicated channels for every team — all-members, exec, marketing, events. Real-time messages, mentions (@James), and notifications so nothing slips through." — 16px `#B0B0B0`
Bullet list (check `#C8102E`):
✓ Club-wide announcements to all members
✓ Team-specific private channels
✓ @mentions and push notifications
✓ Message history — searchable, permanent

**Image:** Dark app UI mockup showing:
- Sidebar with channel list (general, events, marketing highlighted)
- Chat window with real messages (Priya, James, Anya — same as hero)
- Unread badges on channels
- Typing indicator visible

### Block B — Tasks (image left, copy right)

**Copy:**
Eyebrow: "TASK MANAGEMENT" — `#F5B800`
H2: "Every task. Every owner. Every deadline." — 40px bold white
Body: "Create tasks, assign them to specific members, set due dates, and track progress. No more 'I thought you were doing that.'" — 16px `#B0B0B0`
Bullets (check `#F5B800`):
✓ Task creation with assignee + due date
✓ Status columns: To Do / In Progress / Complete
✓ Club-wide task visibility for execs
✓ Completion tracking and accountability

**Image:** Kanban-style dark UI mockup:
- Three columns: TO DO (red header) | IN PROGRESS (amber) | COMPLETE (green)
- Task cards with member avatar + deadline chip
- Progress bar for overall club task completion

### Block C — Events + RSVP (image right, copy left)

**Copy:**
Eyebrow: "EVENT PLANNING" — `#C8102E`
H2: "Plan once. Everyone shows up." — 40px bold white
Body: "Add events to your shared club calendar. Members RSVP directly in the platform. Automated reminders before every event." — 16px `#B0B0B0`
Bullets:
✓ Shared calendar all members can view
✓ One-click RSVP with attendance tracking
✓ Automatic event reminders
✓ RSVP count visible to organizers

**Image:** Calendar dark UI mockup:
- Monthly calendar view, red highlights on event dates
- Event card popup: "Winter Gala · Dec 14 · 📍 UC · ✅ 24 RSVPs"
- RSVP button in red gradient

---

## SECTION 7 — HOW IT WORKS

**Background:** `#111111` with very faint red radial glow top-left

**Eyebrow:** "HOW IT WORKS" — 11px ALL CAPS `#C8102E`
**H2:** "Up and running in under 5 minutes." — 48px weight 800 white

**Layout:** Two columns — left: 4-step numbered list. Right: animated setup wizard mockup.

### Steps (left column):

Each step: horizontal layout — step number circle (48px, 50% radius) + text block.

**Step 1** — circle bg `#C8102E`, number white bold
"Create Your Account"
"Sign up with your official @uoguelph.ca email. Verified university email required — no outside accounts."

**Step 2** — circle border `#C8102E` at 40%, number `#C8102E`
"Enter Your Club Code"
"Your club executive gives you a secure 6-digit access code. Enter it to join your club's private workspace."

**Step 3** — same style
"Set Up Your Profile"
"Add your name, photo, year, and program. Your club directory updates automatically."

**Step 4** — same style
"Start Collaborating"
"Jump into channels, check your tasks, see upcoming events. You're live."

**Admin note** (below steps, small card amber border):
"Club presidents: create your club space, generate your access code, invite your exec team, and build your channels — all in the same 5-minute setup."

### Right — Mockup:

Setup wizard dark UI card (20px radius, shadow):
- Header: window chrome dots + "SETUP WIZARD" label chip
- Field: "Official Guelph Email" → `president@uoguelph.ca`
- Field: "Club Code" → dashes animating in
- Success state: "Welcome to Gryph Club Connect! 👋" toast notification (bottom, dark pill)
- CTA button: "Ready to collaborate! 🚀" — red gradient

---

## SECTION 8 — PRICING

**Background:** `#0A0A0A`

**Eyebrow:** "PRICING" — 11px ALL CAPS `#C8102E`
**H2:** "Start free. Scale when you're ready." — 48px bold white
**Sub:** "No credit card required. Built for students, priced for clubs." — 18px `#B0B0B0`

**Three pricing cards** (horizontal row):

**Free — $0 / month**
Card: `#161616`, border `rgba(255,255,255,0.06)`, 16px radius
Label: "FREE" 11px ALL CAPS `#666666`
Price: "$0" 56px weight 800 white + "/month" `#666666` 16px
Features (✓ `#22C55E`, ✗ `#2A2A2A`):
✓ 1 club workspace
✓ Up to 20 members
✓ 3 channels
✓ Basic task tracking
✓ Event calendar
✗ Admin analytics
✗ Unlimited members
✗ Priority support
CTA: ghost button, border `rgba(255,255,255,0.15)`, text white

**Club Pro — $9 / month** ← FEATURED
Card: `#161616`, border `#C8102E` at 50%, box-shadow `0 0 40px rgba(200,16,46,0.2)`, 16px radius
Top badge: "MOST POPULAR" — gradient `#C8102E`→`#8B0000`, white text, pill, centred top
Label: "CLUB PRO" 11px ALL CAPS `#C8102E`
Price: "$9" 56px bold white + "/month" `#666666`
Sub: "Per club. Cancel anytime."
Features: all ✓ green
✓ Unlimited members
✓ Unlimited channels
✓ Full task management with deadlines
✓ Event calendar + RSVP analytics
✓ Member directory with role permissions
✓ Admin engagement dashboard
✓ File sharing (coming soon)
✓ Priority support
CTA: "Start 14-Day Free Trial" — gradient red, full-width, 10px radius

**Institutional — Contact Us**
Card: `#161616`, border `#F5B800` at 30%, 16px radius
Label: "INSTITUTIONAL" 11px ALL CAPS `#F5B800`
Price: "Custom" 36px bold white
Sub: "University-wide licensing"
Features:
✓ All clubs on one university license
✓ Central admin oversight
✓ Cross-club analytics
✓ LMS and university SSO integration
✓ Dedicated support + onboarding
CTA: solid `#1A1A1A`, border `#F5B800` at 30%, text gold — "Contact Us →"

---

## SECTION 9 — TESTIMONIALS

**Background:** `#111111`

**Eyebrow:** "FROM GUELPH STUDENTS" — 11px ALL CAPS `#C8102E`
**H2:** "Real clubs. Real results." — 48px bold white

**Three testimonial cards** (horizontal row):
Each: `#161616`, border `rgba(255,255,255,0.06)`, 16px radius, padding 32px, left border 3px `#C8102E`

Stars: 5× `#F5B800` star icons

Card 1:
Quote: *"We used to run our whole club through Instagram DMs and a group chat. Gryph Club Connect completely changed how we operate — every exec actually knows what's happening now."*
Avatar: 40px circle, initials "PS" bg `#C8102E`
Name: "Priya Sharma" — 14px bold white
Role: "VP Marketing · Guelph Marketing Association" — 12px `#666666`

Card 2:
Quote: *"As president, the admin dashboard is everything. I can see who's done their tasks, how many people RSVP'd, and what channels are actually being used."*
Avatar: initials "JO" bg `#1A1A3E` (navy)
Name: "James Okafor" — bold white
Role: "President · Engineering Student Society" — `#666666`

Card 3:
Quote: *"Joining three clubs without any confusion is actually possible now. One login, one dashboard — I switch between them in one click."*
Avatar: initials "AL" bg `#1A3A1A` (dark green)
Name: "Anya Lee" — bold white
Role: "Member · GFAB + ESS + GMA" — `#666666`

---

## SECTION 10 — FINAL CTA

**Background:** `#0A0A0A`
**Layout:** Centred, full-width, padding 120px vertical

Large decorative griffin icon (`#C8102E` at 6% opacity) centred behind content as background element.

**Eyebrow pill:** blinking red dot + "NOW AVAILABLE AT UOFG" — 11px ALL CAPS `#C8102E`, pill bg `#C8102E` at 10%, border `#C8102E` at 20%

**H2** (56px weight 900 white):
"Your club deserves better than a group chat."

**Sub** (20px `#B0B0B0` max-width 560px):
"Join every UofG club already running on Gryph Club Connect. Free to start, built to scale."

**Two buttons:**
- "Create Your Club Free →" — gradient red, padding 18px 40px, 10px radius, shadow
- "Book a Demo" — ghost, border `rgba(255,255,255,0.2)`, text white

**Trust line below buttons:** 🔒 "@uoguelph.ca emails only · Free forever plan · No credit card needed"
12px `#666666` centred

---

## FOOTER

**Background:** `#080808`, 1px top border `rgba(255,255,255,0.06)`

**Top row — 4 columns:**

Col 1 — Brand: Griffin logo + "ClubConnect" wordmark + sub: "The official club management platform for University of Guelph." + social icons (Instagram, LinkedIn, X — `#666666` hover `#FFFFFF`)

Col 2 — Product: Features · How It Works · Pricing · For Club Executives · Mobile App (Coming Soon)

Col 3 — Company: About · Blog · Contact · Careers · Privacy Policy · Terms of Service

Col 4 — Get Started: "Join Free" red button + "For university partnerships" link in gold

**Bottom bar:** "© 2026 Gryph Club Connect. University of Guelph. All rights reserved." `#666666` left + "Made in Guelph, Ontario 🦁" right in `#666666`

---

## GLOBAL DESIGN RULES FOR FIGMA AI

1. **Background always `#0A0A0A` or `#111111`** — never white, never light grey, never off-white
2. **Cards always `#161616`** with `rgba(255,255,255,0.06)` border — hover adds red glow
3. **Primary accent = Red `#C8102E`** — used for primary CTAs, active states, key highlights
4. **Secondary accent = Gold `#F5B800`** — used for the "Connect" wordmark, secondary highlights, pricing
5. **White = headings only** — never use white for body text
6. **Body text `#B0B0B0`** — never pure white for paragraphs
7. **Tags/labels: 11px, ALL CAPS, weight 700, letter-spacing 0.1em** — always
8. **Griffin logo:** red body + gold wing accents — appears in navbar, hero, footer, and as decorative watermark
9. **Buttons:** primary = red gradient with shadow. Secondary = ghost with white border. Gold = institutional only.
10. **App mockups:** always dark `#161616` bg, real data (Priya Sharma, James Okafor, Anya Lee, club names GMA/ESS/GFAB), real channel names (#general, #events, #marketing, #exec-team)
11. **No illustrations or clip art** — use dark UI mockups, metric cards, and structural UI elements for visual interest
12. **Spacing system:** 8px base unit. Section padding 120px vertical. Card padding 32px. Gap between cards 24px.
13. **Font: Inter** (weights 300–900) throughout. JetBrains Mono for UI labels, channel names, and code-like elements.
14. **Mobile-first philosophy** reflected in layout — every section readable and usable at 375px width
15. **University specificity** — always show "@uoguelph.ca" in forms, reference specific Guelph clubs (GMA, ESS, GFAB), use "UofG" shorthand

---

*Gryph Club Connect · University of Guelph · Private Campus Club Management Platform · © 2026 · Not affiliated with the University of Guelph administration.*